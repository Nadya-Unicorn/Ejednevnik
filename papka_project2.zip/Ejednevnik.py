import sys
from PyQt5 import uic
from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow, QLabel, QCalendarWidget,\
    QListWidget, QLineEdit, QDialog, QFileDialog, QTableWidget, QTableWidgetItem, QColorDialog
from PyQt5.QtCore import QDate
from PyQt5.QtGui import QColor, QPixmap
from PyQt5.QtCore import Qt

import sqlite3
from docx import Document
from docx.shared import Inches


DATABASE='Scripts\diary_project.db'


class Diary(QMainWindow):
    def __init__(self):
        # Класс основного окна
        super().__init__()
        uic.loadUi('ejednevnyk.ui', self)
        self.setWindowTitle('Ежедневник')
        self.colour_day = '#fafac0'
        self.colour_background = '#000000'
        self.colour_buttons = '#000000'
        self.day = 1
        self.month = 1
        self.year = 2019
        self.date = ''
        self.hour = 0
        self.minute = 0
        self.time = ''
        self.id = 1
        self.pushButton_ShowDay.clicked.connect(self.show_day_events)

        self.week = 0
        self.pushButton_ShowWEEK.clicked.connect(self.show_week_events)

        self.events = []
        self.dict_events = {}

        self.monday = []
        self.tuesday = []
        self.wednesday = []
        self.thursday = []
        self.friday = []
        self.saturday = []
        self.sunday = []

        # self.tabWidget_diary.setStyleSheet("background-color: {}".format('#fefff8'))
        self.pushButton_EditEvent_DAY.clicked.connect(self.edit_event)
        self.pushButton_DeleteEvent_DAY.clicked.connect(self.delete_event)
        self.pushButton_AddEventDAY.clicked.connect(self.add_event)
        self.pushButton_MakeWordFile.clicked.connect(self.make_word_file)
        self.pushButton_ShowMONTH.clicked.connect(self.show_month_events)
        self.pushButton_Colour.clicked.connect(self.change_colour)

        # Добавление в comboBox_ChooseMonth на вкладке "Месяц" возможных вариантов названий месяцев для последующего выбора
        self.monthnames = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь',
                           'Октябрь', 'Ноябрь', 'Декабрь']
        self.comboBox_ChooseMonth.addItems(self.monthnames)
        # Установка количества рядов и столбцов, а также названий столбцов таблицы на вкладке "Месяц"
        self.tableWidget_ShowMonth.setRowCount(6)
        self.tableWidget_ShowMonth.setColumnCount(7)
        self.tableWidget_ShowMonth.setHorizontalHeaderLabels(["Понедельник", "Вторник", "Среда", "Четверг", "Пятница",
                                                              "Суббота", "Воскресенье"])

    def keyPressEvent(self, event):
        # Функция обработки нажатия клавиш на клавиатуре. При одновременном нажатии клавиш "Alt" и "H" вызывается окно
        # для показа подробной информации о выбранном в ListWidget событии.
        if int(event.modifiers()) == (Qt.AltModifier):
            if event.key() == Qt.Key_H:
                self.show_information_about_event()

    def show_day_events(self):
        # Функция выводит в виджет ListWidget все события за выбранный в календаре день
        self.day = self.calendarWidget_DAY.selectedDate().day()
        self.month = self.calendarWidget_DAY.selectedDate().month()
        self.year = self.calendarWidget_DAY.selectedDate().year()

        # Извлечение необходимой информации из базы данных о событиях за выбранный день
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        ask = 'SELECT id, hour, minute, text1 FROM diary where day=' + str(self.day) + ' AND month=' + str(self.month)
        ask += ' AND year=' + str(self.year)
        result = cur.execute(ask).fetchall()
        con.close()

        # Формирование строк, добавление в список
        self.events = []
        for i in result:
            id, hour, minute, text = i
            # print(id)
            timetime2 = str(hour).rjust(2, '0') + ':' + str(minute).rjust(2, '0')
            string = timetime2 + '  ' + text
            self.dict_events[string] = id
            self.events.append(string)

        # Добавление всех строк из списка в виджет listWidget_Day
        self.listWidget_Day.clear()
        self.listWidget_Day.addItems(sorted(self.events))
        self.listWidget_Day.setCurrentRow(0)

    def show_week_events(self):
        # Функция выводит в виджеты ListWidget все события за все дни в выбранную неделю
        self.week, y = self.calendarWidget_WEEK.selectedDate().weekNumber()
        # Получение необходимой информации о событиях за выбранную неделю
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        ask = 'SELECT id, hour, minute, text1, weekday FROM diary where week_number=' + str(self.week)
        ask += ' AND year=' + str(self.year)
        result = cur.execute(ask).fetchall()
        con.close()

        self.monday = []
        self.tuesday = []
        self.wednesday = []
        self.thursday = []
        self.friday = []
        self.saturday = []
        self.sunday = []
        # Формирование списков с нужными строками в конкретные дни недели
        for i in result:
            id, hour, minute, text, weekday = i
            timetime2 = str(hour).rjust(2, '0') + ':' + str(minute).rjust(2, '0')
            string = timetime2 + '  ' + text
            if weekday == 1:
                self.monday.append(string)
            elif weekday == 2:
                self.tuesday.append(string)
            elif weekday == 3:
                self.wednesday.append(string)
            elif weekday == 4:
                self.thursday.append(string)
            elif weekday == 5:
                self.friday.append(string)
            elif weekday == 6:
                self.saturday.append(string)
            elif weekday == 7:
                self.sunday.append(string)
        # Понедельник
        self.listWidget_monday.clear()
        self.listWidget_monday.addItems(sorted(self.monday))

        # Вторник
        self.listWidget_tuesday.clear()
        self.listWidget_tuesday.addItems(sorted(self.tuesday))

        # Среда
        self.listWidget_wednesday.clear()
        self.listWidget_wednesday.addItems(sorted(self.wednesday))

        # Четверг
        self.listWidget_thursday.clear()
        self.listWidget_thursday.addItems(sorted(self.thursday))

        # Пятница
        self.listWidget_friday.clear()
        self.listWidget_friday.addItems(sorted(self.friday))

        # Суббота
        self.listWidget_saturday.clear()
        self.listWidget_saturday.addItems(sorted(self.saturday))

        # Воскресенье
        self.listWidget_sunday.clear()
        self.listWidget_sunday.addItems(sorted(self.sunday))

    def edit_event(self):
        # Функция изменения выбранного события
        # Получение id выбранного события
        row = self.listWidget_Day.currentRow()
        string = self.listWidget_Day.item(row).text()
        self.id = self.dict_events[string]
        # Получение информации о возможности изменения данного события
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        result, h = cur.execute('SELECT change, hour FROM diary WHERE id=' + str(self.id)).fetchone()
        con.close()

        if result == 0:
            # Если событие можно изменять, то
            # Вывод на экран диалогового окна для изменения выбранного события
            Dialog_EditEventApp = Dialog_EditEvent(self.id)
            Dialog_EditEventApp.show()
            Dialog_EditEventApp.exec()
        else:
            # В противном случает на экран выводится диалоговое окно, сообщающее, что данное событие нельзя менять
            Dialog_ImpossibleChangeApp = Dialog_ImpossibleChange()
            Dialog_ImpossibleChangeApp.show()
            Dialog_ImpossibleChangeApp.exec()

    def delete_event(self):
        # Функция для удаления события
        # Получение id выбранного события
        row = self.listWidget_Day.currentRow()
        string = self.listWidget_Day.item(row).text()
        self.id = self.dict_events[string]
        # Вывод на экран диалогового окна, запрашивающего разрешение на удаление данных о событии
        Dialog_DeleteApp = Dialog_Delete(self.id)
        Dialog_DeleteApp.show()
        Dialog_DeleteApp.exec()

    def add_event(self):
        # Функция для создания нового события
        # Вывод на экран диалогового окна для получения и обработки данных о новом событии
        Dialog_NewEventApp = Dialog_NewEvent()
        Dialog_NewEventApp.show()
        Dialog_NewEventApp.exec()

    def make_word_file(self):
        # Функция для создания файла Word
        # Получение id выбранного события
        row = self.listWidget_Day.currentRow()
        string = self.listWidget_Day.item(row).text()
        self.id = self.dict_events[string]
        # print(self.id)
        Dialog_nameWordFileApp = Dialog_nameWordFile(self.id)
        # print('after_init')
        Dialog_nameWordFileApp.show()
        # print('after_show')
        Dialog_nameWordFileApp.exec()

    def show_month_events(self):
        # Вывод событий за выбранный месяц в виджет tableWidget_ShowMonth
        # Получение выбранных пользователем запросов
        for row in range(7):
            for col in range(7):
                self.tableWidget_ShowMonth.setItem(row, col, QTableWidgetItem(''))
        month = self.comboBox_ChooseMonth.currentText()
        year = self.spinBox_year.value()
        # Получение необходимых данных о событиях в выбранный месяц выбранного года
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        ask = 'SELECT day, text1, weekday, month FROM diary WHERE year=' + str(year)
        ask += ' AND month=(SELECT id FROM month_name WHERE important=1 AND name=\'' + month + '\')'
        result = cur.execute(ask).fetchall()
        days, id = cur.execute('SELECT days, id FROM month_name WHERE name=\'' + month + '\'').fetchone()
        con.close()

        # Заполнение ячеек таблицы числами дней месяца
        for i in range(1, days + 1):
            day_of_week = QDate(year, id, i).dayOfWeek()
            col = day_of_week - 1
            row = (i - day_of_week) // 7 + 1
            self.tableWidget_ShowMonth.setItem(row, col, QTableWidgetItem(str(i)))
            if col == 5 or col == 6:
                self.tableWidget_ShowMonth.item(row, col).setBackground(QColor(self.colour_day))

        # Расстановка событий по дням месяца
        for i in result:
            day, text, weekday, month = i
            row = (day - weekday) // 7 + 1
            col = weekday - 1
            string = self.tableWidget_ShowMonth.takeItem(row, col).text()
            new_string = string + '\n' + text
            self.tableWidget_ShowMonth.setItem(row, col, QTableWidgetItem(new_string))
        self.tableWidget_ShowMonth.resizeColumnsToContents()
        self.tableWidget_ShowMonth.resizeRowsToContents()

    def show_information_about_event(self):
        # print('show_information')
        row = self.listWidget_Day.currentRow()
        string = self.listWidget_Day.item(row).text()
        self.id = self.dict_events[string]
        Dialog_InformationApp = Dialog_Information(self.id)
        Dialog_InformationApp.show()
        Dialog_InformationApp.exec()

    def change_colour(self):
        # Функция изменения цветов некоторых элементов
        # Вывод диалогового окна для получения названия элементов и цвета
        Dialog_ColoursApp = Dialog_Colours()
        Dialog_ColoursApp.show()
        Dialog_ColoursApp.exec()
        # Получение выбранных элементов
        result = Dialog_ColoursApp.return_result()
        if bool(result):
            for i in result:
                # Если пользователь выбрал окрасить кнопки, то они будут окрашены в выбранный цвет
                if i == 'button':
                    self.colour_buttons = Dialog_ColoursApp.return_colour()
                    self.pushButton_ShowDay.setStyleSheet("background-color: {}".format(self.colour_buttons))
                    self.pushButton_AddEventDAY.setStyleSheet("background-color: {}".format(self.colour_buttons))
                    self.pushButton_EditEvent_DAY.setStyleSheet("background-color: {}".format(self.colour_buttons))
                    self.pushButton_DeleteEvent_DAY.setStyleSheet(
                        "background-color: {}".format(self.colour_buttons))
                    self.pushButton_MakeWordFile.setStyleSheet("background-color: {}".format(self.colour_buttons))
                    self.pushButton_ShowWEEK.setStyleSheet("background-color: {}".format(self.colour_buttons))
                    self.pushButton_ShowMONTH.setStyleSheet("background-color: {}".format(self.colour_buttons))
                # Если пользователь выбрал поменять цвет заливки выходных дней в таблице, то цвет по умолчанию меняется
                # на выбранный
                elif i == 'days':
                    self.colour_day = Dialog_ColoursApp.return_colour()


class Dialog_NewEvent(QDialog):
    # Класс диалогового окна для создания нового события
    def __init__(self):
        super().__init__()
        uic.loadUi('dialog_add_new_event.ui', self)
        self.setWindowTitle('Новое событие')
        self.day = 1
        self.month = 1
        self.year = 2019
        self.hour = 0
        self.minute = 0
        self.text = ''
        self.place = ''
        self.importance = 0
        self.changeable = 0
        self.FileName = ''
        self.week_day = 1
        self.week_of_year = 1
        self.pushButton_addPicture.clicked.connect(self.add_photo)
        self.buttonBox_Ok_Close.accepted.connect(self.accept_newEvent)
        self.buttonBox_Ok_Close.rejected.connect(self.reject_newEvent)

    def accept_newEvent(self):
        # Функция вызывается при согласии на добавление события
        # получение введенной пользователем информации
        self.day = self.calendarWidget_addNew.selectedDate().day()
        self.month = self.calendarWidget_addNew.selectedDate().month()
        self.year = self.calendarWidget_addNew.selectedDate().year()
        self.week_day = self.calendarWidget_addNew.selectedDate().dayOfWeek()
        self.week_of_year, year = self.calendarWidget_addNew.selectedDate().weekNumber()
        self.hour = self.timeEdit_addNew.time().hour()
        self.minute = self.timeEdit_addNew.time().minute()
        self.place = self.lineEdit_Place_addNew.text()
        self.text = self.lineEdit_TextEvent.text()
        if self.radioButton_YESimp.isChecked():
            self.importance = 1
        else:
            self.importance = 0
        if self.checkBox_noChange.isChecked():
            self.changeable = 1

        # Добавление данных о новом событии в базу данных
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        ask = str(self.day) + ', ' + str(self.month) + ', ' + str(self.year) + ', ' + str(self.hour) + ', '
        ask += str(self.minute) + ', \'' + self.place + '\', \'' + self.text + '\', '
        ask += str(self.importance) + ', ' + str(self.changeable) + ', ' + str(self.week_day)
        ask += ', ' + str(self.week_of_year) + ', \'' + self.FileName + '\''
        que = 'INSERT INTO diary(day, month, year, hour, minute, place, text1, important, change, '
        que += 'weekday, week_number, picture) VALUES(' + ask + ');'
        cur.execute(que)
        con.commit()
        self.close()

    def reject_newEvent(self):
        # Закрытие программы (отказ пользователя)
        self.close()

    def add_photo(self):
        self.FileName = QFileDialog.getOpenFileName(self, 'Выбрать картинку',
                                                    '', "Картинка(*.jpg)")[0]


class Dialog_EditEvent(QDialog):
    # Класс диалогового окна для изменения данных о событии
    def __init__(self, id):
        super().__init__()
        uic.loadUi('dialog_edit_event.ui', self)
        self.setWindowTitle('Изменить событие')
        self.hour = 0
        self.minute = 0
        self.place = ''
        self.text = ''
        self.importance = 0
        self.id = id
        self.buttonBox_OK_Cancel_edit.accepted.connect(self.accept_edit)
        self.buttonBox_OK_Cancel_edit.rejected.connect(self.reject_edit)

    def accept_edit(self):
        # Функция изменения информации о событии. Вызывается при согласии пользователя
        self.hour = self.timeEdit_EditNewTime.time().hour()
        self.minute = self.timeEdit_EditNewTime.time().minute()
        self.place = self.lineEdit_EditNewPlace.text()
        self.text = self.lineEdit_EditNewText.text()

        if self.radioButton_YESnew.isChecked():
            self.importance = 1
        else:
            self.importance = 0

        # Изменение информации о событии в базе данных
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        que = 'UPDATE diary SET hour=' + str(self.hour) + ' , minute=' + str(
            self.minute) + ' , place=\'' + self.place
        que += '\' , text1=\'' + self.text + '\' , important=' + str(self.importance) + ' WHERE id=' + str(self.id)
        cur.execute(que)
        con.commit()
        self.close()

    def reject_edit(self):
        # Закрытие окна (отказ пользователя)
        self.close()


class Dialog_nameWordFile(QDialog):
    # Класс диалогового окна для создания файла Word
    def __init__(self, id):
        super().__init__()
        uic.loadUi('dialog_name_word_file.ui', self)
        self.setWindowTitle('Имя файла')
        self.filename = ''
        self.id = id
        self.buttonBox_OkCancelWord.accepted.connect(self.accept_file)
        self.buttonBox_OkCancelWord.rejected.connect(self.reject_file)

    def accept_file(self):
        # Получение имени файла Word
        self.filename = self.lineEdit_nameWordFile.text()
        if len(self.filename) <= 5 or self.filename[len(self.filename) - 4:] != '.docx':
            self.filename += '.docx'
        # Получение необходимых данных для создания документа
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        ask = 'SELECT id, day, month, year, hour, minute, place, text1, important, change,'
        ask += 'weekday, week_number, picture FROM diary WHERE id=' + str(self.id)
        result = cur.execute(ask).fetchone()
        id, day, month, year, hour, minute, place, text1, important, change, weekday, weeknum, picture = result
        dayname, g = cur.execute('SELECT name_day, number FROM week_days WHERE number=' + str(weekday)).fetchall()[0]
        monthname, cntdays = cur.execute('SELECT rodit_padezh, days FROM month_name WHERE id=' + str(month)).fetchall()[0]
        con.close()

        # Формирование строк для последующей записи в файл
        text_data = 'Дата: ' + str(dayname) + ', ' + str(day) + ' ' + str(monthname) + ' ' + str(year) + ' года'
        text_time = 'Время: ' + str(hour).rjust(2, '0') + ':' + str(minute).rjust(2, '0') + '\n'
        if important == 0:
            text_important = 'Важное\n'
        elif important == 1:
            text_important = 'Не отмечено как важное\n'
        if change == 0:
            text_change = 'Можно изменить\n'
        elif change == 1:
            text_change = 'Нельзя изменить\n'
        if place == '':
            place = 'Нет информации о месте\n'
        elif place != '':
            place = 'Место: ' + place + '\n'

        # Формирование документа
        document = Document()
        document.add_heading(text_data, 0).bold=True
        p = document.add_paragraph(text_time)
        p.add_run(place)
        p.add_run('Текст: ' + text1 + '\n')
        p.add_run(text_time)
        p.add_run(text_important)
        p.add_run(text_change)
        if picture != '':
            document.add_picture(picture,  width=Inches(4))
        document.add_page_break()
        document.save(self.filename)
        self.close()

    def reject_file(self):
        # Закрытие окна (отказ пользователя)
        self.close()


class Dialog_Delete(QDialog):
    # Класс диалогового окна, удаление события
    def __init__(self, id):
        super().__init__()
        uic.loadUi('dialog_delete_yes_no.ui', self)
        self.setWindowTitle('Удаление события')
        self.id = id
        self.buttonBox_YesNo.accepted.connect(self.button_yes)
        self.buttonBox_YesNo.rejected.connect(self.button_no)

    def button_yes(self):
        # Удаление информации о событии из базы данных при согласии на это пользователя
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        cur.execute('DELETE FROM diary WHERE id=' + str(self.id))
        con.commit()
        self.close()

    def button_no(self):
        # Закрытие окна (отказ пользователя)
        self.close()


class Dialog_Information(QDialog):
    # Класс диалогового окна, выводящего на экран подробной информации о выбранном событии
    def __init__(self, id):
        super().__init__()
        uic.loadUi('dialog_information_about_event.ui', self)
        self.setWindowTitle('Информация о событии')
        self.id = id
        self.pixmap = ''
        self.show1()
        self.buttonBox.rejected.connect(self.close1)

    def show1(self):
        # вывод на экран информации о событии
        # Получение из базы данных необходимой информации о событии
        con = sqlite3.connect(DATABASE)
        cur = con.cursor()
        ask = 'SELECT id, day, month, year, hour, minute, place, text1, important, change,'
        ask += 'weekday, week_number, picture FROM diary WHERE id=' + str(self.id)

        result = cur.execute(ask).fetchone()
        id, day, month, year, hour, minute, place, text1, important, change, weekday, weeknum, picture = result
        dayname, g = cur.execute('SELECT name_day, number FROM week_days WHERE number=' + str(weekday)).fetchall()[0]
        monthname, cntdays = cur.execute('SELECT rodit_padezh, days FROM month_name WHERE id=' + str(month)).fetchall()[0]
        con.close()

        # Формирование строк для последующего вывода на экран
        text_data = str(dayname) + ', ' + str(day) + ' ' + str(monthname) + ' ' + str(year) + ' года'
        text_time = str(hour).rjust(2, '0') + ':' + str(minute).rjust(2, '0')
        if important == 0:
            text_important = 'Важное'
        elif important == 1:
            text_important = 'Не отмечено как важное'
        if change == 0:
            text_change = 'Можно изменить'
        elif change == 1:
            text_change = 'Нельзя изменить'
        if place == '':
            place = 'Нет информации'

        # вывод строк в соответствующие label
        self.label_Date.setText(text_data)
        self.label_Time.setText(text_time)
        self.label_Place.setText(place)
        self.label_Text_event.setText(text1)
        self.label_Importance.setText(text_important)
        self.label_Changing.setText(text_change)
        self.pixmap = QPixmap(picture)
        self.label_Image.resize(250, 250)
        self.label_Image.setPixmap(self.pixmap)

    def close1(self):
        # Закрытие окна
        self.close()


class Dialog_ImpossibleChange(QDialog):
    # Класс диалогового окна, выводящего на экран сообщение о том, что событие не может быnь изменено
    def __init__(self):
        super().__init__()
        uic.loadUi('dialog_impossible_delete.ui', self)
        self.setWindowTitle('Сообщение')
        self.buttonBox_impossible.accepted.connect(self.acceptExit)

    def acceptExit(self):
        # Закрытие окна
        self.close()


class Dialog_Colours(QDialog):
    # Класс диалогового окна для предоставления пользователь права выбора элементов, которые будут окрашены и цвета,
    # в который будут окрашены элементы
    def __init__(self):
        super().__init__()
        # print('Dialog_Colours')
        uic.loadUi('dialog_colours.ui', self)
        self.setWindowTitle('Изменить цвета')
        self.colour = ''
        self.results = []
        self.buttonBox_colour.rejected.connect(self.reject_colour)
        self.buttonBox_colour.accepted.connect(self.accept_colour)

    def accept_colour(self):
        # Сохранение названий выбранных пользователем элементов
        if self.checkBox_buttons.isChecked():
            self.results.append('button')
        if self.checkBox_monthweekends.isChecked():
            self.results.append('days')
        color = QColorDialog.getColor()
        if color.isValid():
            self.colour = color.name()
        self.close()

    def reject_colour(self):
        # Закрытие программы (отказ пользователя)
        self.close()

    def return_result(self):
        # Возвращение названий выбранных пользователем элементов
        return self.results

    def return_colour(self):
        # Возвращение выбранного пользователем цвета
        return self.colour


app = QApplication(sys.argv)
ex = Diary()
ex.show()
sys.exit(app.exec_())